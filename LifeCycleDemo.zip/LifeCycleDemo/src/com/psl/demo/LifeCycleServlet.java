package com.psl.demo;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class LifeCycleServlet
 */
public class LifeCycleServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	public LifeCycleServlet(){
		System.out.println("Servlet object is created");
	}
		
	@Override
	public void init() throws ServletException {
	System.out.println("Servlet is initialized.....");
	String username=getServletConfig().getInitParameter("user");
	System.out.println("user is"+username);		
	}
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	  System.out.println("get request is processed...");
	  
	  Date date=new Date();
	  response.setContentType("text/plain");
	  PrintWriter out=response.getWriter();
	  //dynamic web pages
	  out.println("<html>"+
	   "<body>"+
	    "Today "+date+
	   "</body>"+
	   "</html>");
	}
	
	@Override
	public void destroy() {
		// TODO Auto-generated method stub
		System.out.println("destroy called:  this is not in our hand it depends on web container");
	}

}
